#include <iostream>
#include <string>
using namespace std;

class node
{
public:
    string name;
    static int a;
    float duration;
    int id;
    node *next;
    node *prev;

    node()
    {
        a++;
        name = "";
        duration = 0.0;
        id = a;
        next = prev = nullptr;
    }

    node(string b, float d)
    {
        a++;
        name = b;
        duration = d;
        id = a;
        next = prev = nullptr;
    }
};

int node::a = 0;

class dllist
{
    node *head;
    node *tail;
    node *current;

public:
    dllist()
    {
        current = head = tail = nullptr;
    }

    ~dllist() 
    {
        node* temp = head;
        while (temp != nullptr) {
            node* nextNode = temp->next;
            delete temp;
            temp = nextNode;
        }
    }

    bool is_empty()
    {
        return (head == nullptr);
    }

    void add_song(string n, float d)
    {
        node *newnode = new node(n, d);

        if (is_empty())
        {
            head = tail = newnode;
            return;
        }

        tail->next = newnode;
        newnode->prev = tail;
        tail = newnode;
    }

    void play_next()
    {
        if (is_empty()) {
            cout << "\nPlaylist is empty!\n";
            return;
        }

        if (current == nullptr) {
            cout << "\nFirst song played!\n";
            current = head;
        } 
        else if (current->next == nullptr) {
            cout << "\nYou reached the end of the playlist!\n";
            return; 
        } 
        else {
            current = current->next;
            cout << "\nNext song played!\n";
        }

        cout << "Current song now is: " << current->name << endl;
    }

    void play_prev()
    {
        if (is_empty()) {
            cout << "\nPlaylist is empty!\n";
            return;
        }

        if (current == nullptr || current->prev == nullptr) {
            cout << "\nNo previous songs!\n";
            return; 
        } 
        else {
            current = current->prev;
            cout << "\nPrev song played!\n";
        }

        cout << "Current song now is: " << current->name << endl;
    }

    void del_by_name(string b)
    {
        if (is_empty()) {
            cout << "Playlist is empty! Nothing to delete.\n";
            return;
        }

        node *temp = head;

        while (temp != nullptr && temp->name != b) {
            temp = temp->next;
        }

        if (temp == nullptr) {
            cout << "Song not found!\n";
            return;
        }

        if (temp == current) {
            current = nullptr;
            cout << "[Note: Currently playing song was removed. Playback stopped.]\n";
        }

        if (temp == head) {
            head = head->next;
            if (head != nullptr) {
                head->prev = nullptr;
            } else {
                tail = nullptr; 
            }
        }
        else if (temp == tail) {
            tail = tail->prev;
            if (tail != nullptr) {
                tail->next = nullptr;
            }
        }
        else {
            temp->prev->next = temp->next;
            temp->next->prev = temp->prev;
        }

        delete temp;
        cout << "Song '" << b << "' deleted!\n";
    }

    void reverse()
    {
        if (is_empty() || head->next == nullptr) {
            return;
        }

        node *temp = nullptr;
        node *curr = head;
        tail = head;

        while (curr != nullptr) {
            temp = curr->prev;
            curr->prev = curr->next;
            curr->next = temp;
            curr = curr->prev;
        }

        if (temp != nullptr) {
            head = temp->prev;
        }
        
        cout << "\nPlaylist has been reversed!\n";
    }

    void print()
    {
        if (is_empty())
        {
            cout << "Playlist is empty!\n";
            return;
        }
        node *temp = head;
        while (temp != nullptr)
        {
            cout << "\nName: " << temp->name << "\nId: " << temp->id << "\nDuration: " << temp->duration << " mins" << endl;
            cout << "-------------------------------";
            temp = temp->next;
        }
        cout << endl;
    }
};

int main()
{
    dllist l;
    l.add_song("Khubaib", 5.5);
    l.add_song("Ali", 1.2);
    l.add_song("Hussain", 7.0);
    
    l.print();
    
    l.del_by_name("Ali");
    
    l.add_song("Huzaifa", 7.5);
    
    l.print();

    l.play_next();
    l.play_next();
    l.play_prev();

    l.reverse();
    l.print();

    return 0;
}