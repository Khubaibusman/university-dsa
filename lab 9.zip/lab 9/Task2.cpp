#include <iostream>
using namespace std;

class node
{
public:
    int playerID;
    int score;
    node *next;

    node(int id, int s = 0)
    {
        playerID = id;
        score = s;
        next = nullptr;
    }
};

class game_system
{
    node *current;
    int count;

public:
    game_system()
    {
        current = nullptr;
        count = 0;
    }

    ~game_system()
    {
        if (current == nullptr) return;
        node *temp = current->next;
        while (temp != current)
        {
            node *nextNode = temp->next;
            delete temp;
            temp = nextNode;
        }
        delete current;
    }

    bool is_empty()
    {
        return (current == nullptr);
    }

    void add_player(int id, int s = 0)
    {
        node *newnode = new node(id, s);

        if (is_empty())
        {
            current = newnode;
            current->next = current;
        }
        else
        {
            node *temp = current;
            while (temp->next != current)
            {
                temp = temp->next;
            }
            temp->next = newnode;
            newnode->next = current;
        }
        count++;
    }

    void remove_player(int id)
    {
        if (is_empty())
        {
            return;
        }

        node *curr = current;
        node *prev = nullptr;

        if (curr->playerID == id && curr->next == current)
        {
            delete curr;
            current = nullptr;
            count--;
            return;
        }

        if (curr->playerID == id)
        {
            prev = current;
            while (prev->next != current)
            {
                prev = prev->next;
            }
            current = current->next;
            prev->next = current;
            delete curr;
            count--;
            check_winner();
            return;
        }

        prev = current;
        curr = current->next;

        while (curr != current)
        {
            if (curr->playerID == id)
            {
                prev->next = curr->next;
                delete curr;
                count--;
                check_winner();
                return;
            }
            prev = curr;
            curr = curr->next;
        }
    }

    void next_turn()
    {
        if (is_empty())
        {
            return;
        }
        current = current->next;
    }

    void skip_player()
    {
        if (is_empty() || current->next == current)
        {
            return;
        }
        current = current->next->next;
    }

    void check_winner()
    {
        if (count == 1 && current != nullptr)
        {
            cout << "\nGame Over! Winner is Player " << current->playerID << " with score: " << current->score << endl;
        }
    }

    void display()
    {
        if (is_empty())
        {
            cout << "No players in the game.\n";
            return;
        }
        
        cout << "\n--- Game State ---\n";
        node *temp = current;
        do
        {
            cout << "Player ID: " << temp->playerID << " | Score: " << temp->score << endl;
            temp = temp->next;
        } while (temp != current);
        
        cout << "Current Turn: Player " << current->playerID << "\n------------------\n";
    }
};

int main()
{
    game_system game;

    game.add_player(101, 0);
    game.add_player(102, 5);
    game.add_player(103, 10);
    game.add_player(104, 2);

    game.display();

    game.next_turn();
    game.display();

    game.skip_player();
    game.display();

    game.remove_player(101);
    game.remove_player(103);
    game.display();

    game.remove_player(104);

    return 0;
}