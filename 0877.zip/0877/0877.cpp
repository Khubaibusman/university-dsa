#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int d) {
        data = d;
        next = NULL;
    }
};

class Stack {
public:
    Node* top;

    Stack() {
        top = NULL;
    }

    void push(int d) {
        Node* n = new Node(d);
        n->next = top;
        top = n;
    }

    int pop() {
        if (top == NULL) {
            return -1;
        }
        int x = top->data;
        Node* temp = top;
        top = top->next;
        delete temp;
        return x;
    }

    bool empty() {
        if (top == NULL) {
            return true;
        }
        return false;
    }

    void show() {
        Node* temp = top;
        while (temp != NULL) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << "\n";
    }
};

void reverse(Stack& s) {
    Stack s1;
    Stack s2;

    while (s.empty() == false) {
        int x = s.pop();
        s1.push(x);
    }

    while (s1.empty() == false) {
        int x = s1.pop();
        s2.push(x);
    }

    while (s2.empty() == false) {
        int x = s2.pop();
        s.push(x);
    }
}

int main() {
    Stack s;

    s.push(10);
    s.push(20);
    s.push(30);
    s.push(40);

    cout << "Original:\n";
    s.show();

    reverse(s);

    cout << "Reversed:\n";
    s.show();

    return 0;
}