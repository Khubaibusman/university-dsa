#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;
};

class ChainingHash {
    Node** table;
    int size;
    int count;

    void rehash() {
        cout << "Load factor > 0.7! Rehashing..." << endl;
        int oldSize = size;
        Node** oldTable = table;
        
        size = size * 2;
        table = new Node*[size];
        for (int i = 0; i < size; i++) {
            table[i] = NULL;
        }
        
        count = 0;
        for (int i = 0; i < oldSize; i++) {
            Node* temp = oldTable[i];
            while (temp != NULL) {
                insert(temp->data);
                Node* toDelete = temp;
                temp = temp->next;
                delete toDelete;
            }
        }
        delete[] oldTable;
    }

public:
    ChainingHash() {
        size = 10;
        count = 0;
        table = new Node*[size];
        for (int i = 0; i < size; i++) {
            table[i] = NULL;
        }
    }

    void insert(int key) {
        float loadFactor = (count * 1.0) / size;
        if (loadFactor > 0.7) {
            rehash();
        }

        int index = key % size;
        Node* newNode = new Node;
        newNode->data = key;
        newNode->next = table[index];
        table[index] = newNode;
        count++;
    }

    void display() {
        for (int i = 0; i < size; i++) {
            cout << i << ": ";
            Node* temp = table[i];
            while (temp != NULL) {
                cout << temp->data << " -> ";
                temp = temp->next;
            }
            cout << "NULL\n";
        }
    }
};

class BucketHash {
    int buckets[3][20];
    int count[3];

public:
    BucketHash() {
        for (int i = 0; i < 3; i++) {
            count[i] = 0;
        }
    }

    void insert(int key) {
        int index = key % 3;
        buckets[index][count[index]] = key;
        count[index]++;
    }

    void display() {
        for (int i = 0; i < 3; i++) {
            cout << "Bucket " << i << ": ";
            for (int j = 0; j < count[i]; j++) {
                cout << buckets[i][j] << " ";
            }
            cout << "\n";
        }
    }
};

int main() {
    int skus[] = {17, 26, 15, 9, 11, 43, 75, 19, 35, 45, 55, 9, 10, 21, 61, 23};
    
    cout << "--- Chaining Method ---" << endl;
    ChainingHash ch;
    for (int i = 0; i < 16; i++) {
        ch.insert(skus[i]);
    }
    ch.display();

    cout << "\n--- Bucketing Method ---" << endl;
    BucketHash bh;
    for (int i = 0; i < 16; i++) {
        bh.insert(skus[i]);
    }
    bh.display();

    return 0;
}