#include <iostream>
using namespace std;

class MinHeap {
    int arr[100];
    int size;

    void swap(int& a, int& b) {
        int temp = a;
        a = b;
        b = temp;
    }

    void heapifyDown(int i) {
        int smallest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        if (left < size && arr[left] < arr[smallest]) {
            smallest = left;
        }
        if (right < size && arr[right] < arr[smallest]) {
            smallest = right;
        }
        if (smallest != i) {
            swap(arr[i], arr[smallest]);
            heapifyDown(smallest);
        }
    }

    void heapifyUp(int i) {
        while (i != 0 && arr[(i - 1) / 2] > arr[i]) {
            swap(arr[i], arr[(i - 1) / 2]);
            i = (i - 1) / 2;
        }
    }

public:
    MinHeap() {
        size = 0;
    }

    void buildHeap(int input[], int n) {
        size = n;
        for (int i = 0; i < n; i++) {
            arr[i] = input[i];
        }
        for (int i = (size / 2) - 1; i >= 0; i--) {
            heapifyDown(i);
        }
    }

    void insert(int val) {
        arr[size] = val;
        size++;
        heapifyUp(size - 1);
    }

    int extractMin() {
        if (size == 0) return -1;
        int root = arr[0];
        arr[0] = arr[size - 1];
        size--;
        heapifyDown(0);
        return root;
    }

    void extractTop3() {
        int top1 = extractMin();
        int top2 = extractMin();
        int top3 = extractMin();
        cout << top1 << " " << top2 << " " << top3 << endl;
    }

    void print() {
        for (int i = 0; i < size; i++) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    int tasks[] = {15, 10, 20, 8, 12, 25, 18};
    MinHeap h;
    
    h.buildHeap(tasks, 7);
    cout << "Heap after building: ";
    h.print();

    h.insert(5);
    cout << "Heap after inserting 5: ";
    h.print();

    int minTask = h.extractMin();
    cout << "Extracted min: " << minTask << endl;
    cout << "Heap after extraction: ";
    h.print();

    cout << "Top 3 tasks: ";
    h.extractTop3();
    cout << "Heap after extracting top 3: ";
    h.print();

    return 0;
}