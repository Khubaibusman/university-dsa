#include <iostream>
using namespace std;
int main() {

	int arr[3];

	int num=0;
	int size = 3;

	cout << "Please enter 3 numbers in array: " << endl;
		for (int i = 0; i < size; i++) {
			cout << "Number " << i + 1 << ": ";
			cin >> arr[i];
		}

		for (int i = 0; i <size; i++) {
			
			num *= 10;
			num += arr[i];


		}
		num++;

		cout << "Output: " << num << endl;

	system ("pause");
	return 0;
}