#include <iostream>
using namespace std;

int main() {

    int arr[6] = {2,3,3,4,4,7};
    int size = 6;

    for(int j = 0; j < size-1; j++) {
        if(arr[j] == arr[j+1]) {

            for(int i = j; i < size-1; i++) {
                arr[i] = arr[i+1];
            }

            size--;
            j--;
        }
    }

    for(int j = 0; j < size; j++) {
        cout << arr[j] << " ";
    }

    cout << endl;
    return 0;
}