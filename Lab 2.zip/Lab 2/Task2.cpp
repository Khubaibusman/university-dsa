#include <iostream>
using namespace std;
int main() {

	int arr[8] = {0};
	int mini;
	int num[3];
	cout << "Please enter 8 elements: " << endl;
	for (int i = 0; i < 8; i++) {
		cout << "Number " << i + 1 << ": ";
		cin >> arr[i];
	}
	
	mini = arr[0];
	for (int i = 0; i < 8; i++) {
		if (arr[i] < mini) {
			mini = arr[i];
		}
	}

	for (int i = 0; i < 3; i++) {
		num[i] = mini;
	}

	for (int i = 0; i < 8; i++) {
		if (arr[i] > num[0]) {
			num[0] = arr[i];
		}
	}

	for (int i = 0; i < 8; i++) {
		if (arr[i] > num[1] && arr[i] != num[0]) {
			num[1] = arr[i];
		}
	}

	for (int i = 0; i < 8; i++) {
		if (arr[i] > num[2] && arr[i] != num[0] && arr[i] != num[1]) {
			num[2] = arr[i];
		}
	}

	cout << "3rd Highest Number is: "<<num[2];


	cout << endl;
	system("pause");
	return 0;
}