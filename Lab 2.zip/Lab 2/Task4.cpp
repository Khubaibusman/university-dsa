#include <iostream>
using namespace std;

int main()
{
    int arr[] = {0,0,1,0,1,1,1,1};
    int size = 8;

    int maxCount = 1;
    int count = 1;

    for(int i = 1; i < size; i++)
    {
        if(arr[i] == arr[i-1])
        {
            count++;
        }
        else
        {
            count = 1;
        }

        if(count > maxCount)
        {
            maxCount = count;
        }
    }

    cout << maxCount;

    return 0;
}