#include <iostream>
#include <string>
using namespace std;

class CmdL {
private:
    string* words;
    int maxSize;
    int howManyItems;
    int firstSpot;
    int lastSpot;

    void makeBig() {
        int newMaxSize = maxSize * 2;
        if (newMaxSize > 10) {
            newMaxSize = 10;
        }
        
        string* newWords = new string[newMaxSize];
        
        for (int step = 0; step < howManyItems; step = step + 1) {
            newWords[step] = words[(firstSpot + step) % maxSize];
        }
        
        delete[] words;
        words = newWords;
        firstSpot = 0;
        lastSpot = howManyItems - 1;
        maxSize = newMaxSize;
        
        cout << "[System] Array size changed to " << maxSize << ".\n";
    }

public:
    CmdL() {
        maxSize = 4;
        words = new string[maxSize];
        howManyItems = 0;
        firstSpot = 0;
        lastSpot = -1;
    }

    ~CmdL() { 
        delete[] words; 
    }

    void getCommand(string newWord) {
        if (howManyItems == maxSize && maxSize < 10) {
            makeBig();
        }

        lastSpot = (lastSpot + 1) % maxSize;
        words[lastSpot] = newWord;

        if (howManyItems == maxSize) {
            firstSpot = (firstSpot + 1) % maxSize;
            cout << "[Warning] Full! Oldest command removed.\n";
        } else {
            howManyItems = howManyItems + 1;
        }
        
        cout << "Got: " << newWord << "\n";
    }
};

int main() {
    CmdL Robot;

    Robot.getCommand("MOVE 10");
    Robot.getCommand("TURN LEFT");
    Robot.getCommand("MOVE 5");
    Robot.getCommand("TURN RIGHT");
    
    Robot.getCommand("JUMP"); 
    
    for(int i = 0; i < 6; i++) {
        Robot.getCommand("SPIN"); 
    }

    return 0;
}