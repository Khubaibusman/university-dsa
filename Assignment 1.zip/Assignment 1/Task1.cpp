#include <iostream>
#include <string>
using namespace std;

class DroneStack {
private:
    string* d_Names;
    int* d_Levels;
    int maxItems;
    int topSpot;

public:
    DroneStack(int size = 100) {
        maxItems = size;
        d_Names = new string[maxItems];
        d_Levels = new int[maxItems];
        topSpot = -1;
    }

    ~DroneStack() {
        delete[] d_Names;
        delete[] d_Levels;
    }

    void push(string name, int level) {
        if (topSpot < maxItems - 1) {
            topSpot = topSpot + 1;
            d_Names[topSpot] = name;
            d_Levels[topSpot] = level;
        }
    }

    void pop() {
        if (topSpot >= 0) {
            topSpot = topSpot - 1;
        }
    }

    string topName() {
        return d_Names[topSpot];
    }

    int topLevel() {
        return d_Levels[topSpot];
    }

    bool isEmpty() {
        return topSpot == -1;
    }
};

class DroneDispatcher {
private:
    DroneStack mainStack;

public:
    void addDrone(string name, int level) {
        DroneStack helperStack;

        while (!mainStack.isEmpty() && mainStack.topLevel() > level) {
            helperStack.push(mainStack.topName(), mainStack.topLevel());
            mainStack.pop();
        }

        mainStack.push(name, level);

        while (!helperStack.isEmpty()) {
            mainStack.push(helperStack.topName(), helperStack.topLevel());
            helperStack.pop();
        }
        
        cout << "Added drone " << name << " with priority " << level << ".\n";
    }

    void dispatchDrone() {
        if (mainStack.isEmpty()) {
            cout << "No drones available.\n";
            return;
        }
        
        cout << "Sent Drone: " << mainStack.topName() 
             << " (Priority " << mainStack.topLevel() << ")\n";
        mainStack.pop();
    }
};

int main() {
    DroneDispatcher DeliverySystem;

    DeliverySystem.addDrone("Drone_A", 2);
    DeliverySystem.addDrone("Drone_B", 5); 
    DeliverySystem.addDrone("Drone_C", 1);
    DeliverySystem.addDrone("Drone_D", 8);

    cout << "\n--- Dispatching ---\n";
    DeliverySystem.dispatchDrone(); 
    DeliverySystem.dispatchDrone(); 
    DeliverySystem.dispatchDrone(); 

    return 0;
}