#include <iostream>
#include <string>
using namespace std;

class HtmlStack {
private:
    string* tagWords;
    int* lineNumbers;
    int maxSize;
    int topSpot;

public:
    HtmlStack(int size = 100) {
        maxSize = size;
        tagWords = new string[maxSize];
        lineNumbers = new int[maxSize];
        topSpot = -1;
    }

    ~HtmlStack() { 
        delete[] tagWords; 
        delete[] lineNumbers; 
    }

    void push(string word, int line) {
        if (topSpot < maxSize - 1) {
            topSpot = topSpot + 1;
            tagWords[topSpot] = word;
            lineNumbers[topSpot] = line;
        }
    }

    void pop() {
        if (topSpot >= 0) {
            topSpot = topSpot - 1;
        }
    }

    string topWord() {
        return tagWords[topSpot];
    }

    int topLine() {
        return lineNumbers[topSpot];
    }

    bool isEmpty() {
        return topSpot == -1;
    }
};

void checkHtmlWord(string word, int line, HtmlStack& myStack) {
    bool isClosingWord = false;
    if (word[0] == '/') {
        isClosingWord = true;
    }
    
    if (isClosingWord == false) {
        myStack.push(word, line);
    } else {
        string plainWord = "";
        for (int i = 1; i < word.length(); i++) {
            plainWord = plainWord + word[i];
        }
        
        if (myStack.isEmpty()) {
            cout << "Error: Closing tag <" << word << "> on line " 
                 << line << " with no opening tag.\n";
            return;
        }
        
        if (myStack.topWord() == plainWord) {
            myStack.pop();
        } else {
            cout << "Error: Wrong tag on line " << line 
                 << ". Expected </" << myStack.topWord() 
                 << ">, found <" << word << ">.\n";
        }
    }
}

void findLeftovers(HtmlStack& myStack) {
    while (myStack.isEmpty() == false) {
        cout << "Error: Opening tag <" << myStack.topWord() 
             << "> on line " << myStack.topLine() 
             << " was never closed.\n";
        myStack.pop();
    }
}

int main() {
    HtmlStack myCheckerStack;

    checkHtmlWord("html", 1, myCheckerStack);
    checkHtmlWord("body", 2, myCheckerStack);
    checkHtmlWord("div", 3, myCheckerStack);
    
    checkHtmlWord("/div", 5, myCheckerStack);
    
    checkHtmlWord("/p", 6, myCheckerStack);
    
    checkHtmlWord("/html", 8, myCheckerStack); 

    findLeftovers(myCheckerStack);

    return 0;
}